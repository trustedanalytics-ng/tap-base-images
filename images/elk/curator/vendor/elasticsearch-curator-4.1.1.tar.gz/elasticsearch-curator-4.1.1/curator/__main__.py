
"""Executed when package directory is called as a script"""

from .curator import main
main()
