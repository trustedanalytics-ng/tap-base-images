from . import repomgrcli

def main():
    repomgrcli.repo_mgr_cli()
