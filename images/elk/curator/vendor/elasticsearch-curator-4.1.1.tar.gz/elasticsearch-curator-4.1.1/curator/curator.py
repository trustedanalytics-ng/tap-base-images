import click
from .cli import cli

def main():
    cli()
